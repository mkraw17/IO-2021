import numpy as np
import PyQt5 as py
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from functools import partial
from PyQt5 import QtCore as Qt
from PyQt5.QtCore import *
from functools import partial
import random
import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",

)

products=[]
kwota='0.00'
obecny_produkt=''
zalogowany=0
klientID=0



def conv(tab):
    global tablica
    wynik = ''
    for i in tab:
        wynik += i + '\n'
    return wynik

class Window(QWidget):
    def __init__(self):

        super().__init__()
        global tryb
        self.layout = QVBoxLayout()
        self.resize(900, 668)
        self.setWindowTitle("Kaufland")
        tlo = QLabel(self)
        tlo.setStyleSheet("background-image: url(SG.png); border : none")
        tlo.setGeometry(0, 0, 900, 668)

        start = QPushButton(self)
        start.setStyleSheet("border-radius:115; ")
        start.setGeometry(335, 280, 230, 230)
        start.clicked.connect(self.okno_skan)


        self.show()


    def restart(self):
        self.close()
        tlo = QLabel(self)
        tlo.setStyleSheet("background-image: url(SG.png); border : none")
        tlo.setGeometry(0, 0, 900, 668)

        start = QPushButton(self)
        start.setStyleSheet("border-radius:115; ")
        start.setGeometry(335, 280, 230, 230)
        start.clicked.connect(self.okno_skan)

        self.show()

    def skanuj1(self):
        global tablica,mydb,products,kwota,obecny_produkt
        mycursor = mydb.cursor()
        sql="SELECT code FROM io.products"
        mycursor.execute(sql)
        myresult=mycursor.fetchall()
        code_tab=[]
        for i in myresult:
            code_tab.append(i[0])
        kod=code_tab[random.randint(0,len(code_tab)-1)]
        sql = "SELECT name,price, inStock FROM io.products where code = %s"
        adr = (str(kod),)
        mycursor.execute(sql, adr)
        myresult = mycursor.fetchall()
        name=myresult[0][0]
        price = myresult[0][1]
        inStock = myresult[0][2]
        inStock = int(inStock) - 1
        kwota=float(kwota)
        kwota+=price
        kwota=round(kwota,2)
        kwota=str(kwota)
        products.append(str(name) + '              ' + str(price) + 'zł')
        obecny_produkt=str(name) + '\n' + str(price) + 'zł'
        sql = "UPDATE io.products SET inStock = %s WHERE code = %s;"
        adr = (inStock, kod, )
        mycursor.execute(sql, adr)
        mydb.commit()
        self.okno_skan()


    def okno_skan(self):
        global kwota,tablica,products,obecny_produkt
        self.close()
        t = QLabel(self)
        t.setGeometry(0, 0, 900, 668)
        t.setStyleSheet("background-image: url(skan.png); border : none")

        skanuj = QPushButton(self)
        skanuj.setStyleSheet("border-radius:30; ")
        skanuj.setText("SKANUJ")
        skanuj.setFont(QFont('Arial', 20))
        skanuj.setGeometry(40, 538, 435, 115)
        skanuj.clicked.connect(self.skanuj1)

        zatwierdz = QPushButton(self)
        zatwierdz.setStyleSheet("border-radius:30; ")
        zatwierdz.setText("ZATWIERDŹ")
        zatwierdz.setFont(QFont('Arial', 20))
        zatwierdz.setGeometry(510, 538, 335, 115)
        zatwierdz.clicked.connect(self.podsumowanie)

        suma = QLabel(self)
        suma.setText("SUMA: ")
        suma.setFont(QFont('Arial', 20))
        suma.setGeometry(530, 387, 148, 115)

        suma_i = QLabel(self)
        suma_i.setText(kwota)
        suma_i.setFont(QFont('Arial', 20))
        suma_i.setGeometry(700, 387, 148, 115)

        obecny = QLabel(self)
        obecny.setText(obecny_produkt)
        obecny.setFont(QFont('Arial', 20))
        obecny.setGeometry(100, 230, 300, 115)

        funk=partial(self.skanuj1)


        scroll = ScrollLabel(self)
        scroll.setGeometry(524, 60, 310, 320)
        scroll.setText(conv(products))
        scroll.setStyleSheet("background-color: white; border: none")


        self.show()

    def podsumowanie(self):
        global products
        self.close()

        t1 = QLabel(self)
        t1.setGeometry(0, 0, 900, 668)
        t1.setStyleSheet("background-image: url(podsumowanie.png); border : none")

        blik = QPushButton(self)
        blik.setStyleSheet("border-radius:30;")
        blik.setGeometry(523, 72, 300, 150)
        blik.clicked.connect(self.Blik)

        mastrcrd = QPushButton(self)
        mastrcrd.setStyleSheet("border-radius:30;")
        mastrcrd.setGeometry(523, 242, 300, 210)
        mastrcrd.clicked.connect(self.Karta)

        ret = QPushButton(self)
        ret.setStyleSheet("border-radius:30;")
        ret.setGeometry(57, 493, 378, 121)
        ret.setText("POWRÓT")
        ret.setFont(QFont('Arial', 20))
        ret.clicked.connect(self.okno_skan)

        lojal = QPushButton(self)
        lojal.setStyleSheet("border-radius:30;")
        lojal.setGeometry(501, 493, 370, 121)
        lojal.setText("ZALOGUJ")
        lojal.setFont(QFont('Arial', 20))
        lojal.clicked.connect(self.zaloguj)


        scroll = ScrollLabel(self)
        scroll.setGeometry(60, 60, 370, 360)
        scroll.setText(conv(products))
        scroll.setStyleSheet("background-color: white; border: none")
        self.show()

    def logowanie(self,pesel_n,password,label):
        global mydb,zalogowany,klientID
        pesel=pesel_n.text()
        haslo=password.text()
        mycursor = mydb.cursor()
        sql = "SELECT pesel,password,ID FROM io.customers where pesel = %s and password = %s"
        adr = (str(pesel), str(haslo),)
        mycursor.execute(sql, adr)
        myresult = mycursor.fetchall()

        if len(myresult)==0:
            label.setStyleSheet("border: none; background-color: white; color: red")
        else:
            zalogowany=1
            klientID=myresult[0][2]
            self.zalogowany()

    def zalogowany(self):
        self.close()
        t = QLabel(self)
        t.setGeometry(0, 0, 900, 668)
        t.setStyleSheet("background-color: white; border : none")

        t1 = QLabel(self)
        t1.setGeometry(0, 0, 900, 668)
        t1.setStyleSheet("background-image: url(zalogowany.png); border : none")

        blik = QPushButton(self)
        blik.setStyleSheet("border-radius:30; ")
        blik.setGeometry(333, 102, 300, 150)
        blik.clicked.connect(self.Blik)

        mastrcrd = QPushButton(self)
        mastrcrd.setStyleSheet("border-radius:30; ")
        mastrcrd.setGeometry(343, 315, 300, 210)
        mastrcrd.clicked.connect(self.Karta)
        self.show()

    def zaloguj(self):
        self.close()
        regex=QRegExp("[0-9]+")
        validator=QRegExpValidator(regex)
        t = QLabel(self)
        t.setGeometry(0, 0, 900, 668)
        t.setStyleSheet("background-color: white; border : none")

        t1 = QLabel(self)
        t1.setGeometry(0, 0, 900, 668)
        t1.setStyleSheet("background-image: url(log.png); border : none")


        error = QLabel(self)
        error.setGeometry(390, 80, 400, 40)
        error.setStyleSheet("border: none; background-color: white; color: white")
        error.setText('ZŁE DANE!')
        error.setFont(QFont('Arial', 14))

        login = QLineEdit(self)
        login.setMaxLength(20)
        login.setStyleSheet("border: 2px solid line; background-color: white;")
        login.setFont(QFont('Arial', 18))
        login.setGeometry(250, 173, 400, 66)
        login.setMaxLength(11)
        login.setValidator(validator)

        login_l = QLabel(self)
        login_l.setGeometry(400, 128, 400, 40)
        login_l.setStyleSheet("border: none; background-color: white;")
        login_l.setText('PESEL')
        login_l.setFont(QFont('Arial', 20))

        password = QLineEdit(self)
        password.setMaxLength(20)
        password.setStyleSheet("border: 2px solid line; background-color: white;")
        password.setFont(QFont('Arial', 18))
        password.setGeometry(250, 323, 400, 66)

        password_l = QLabel(self)
        password_l.setGeometry(410, 278, 400, 40)
        password_l.setStyleSheet("border: none; background-color: white;")
        password_l.setText('hasło')
        password_l.setFont(QFont('Arial', 20))


        zalog = QPushButton(self)
        zalog.setStyleSheet("border-radius:20; background-color: gray")
        zalog.setText("ZALOGUJ")
        zalog.setFont(QFont('Arial', 20))
        zalog.setGeometry(320, 423, 250, 66)
        zalog_p=partial(self.logowanie,login,password,error)
        zalog.clicked.connect(zalog_p)

        zareje = QPushButton(self)
        zareje.setStyleSheet("border-radius:20; background-color: gray")
        zareje.setText("ZAREJESTRUJ")
        zareje.setFont(QFont('Arial', 20))
        zareje.setGeometry(320, 503, 250, 66)
        zareje.clicked.connect(self.rejestracja)

        wstecz = QPushButton(self)
        wstecz.setStyleSheet("border-radius:20; background-color: gray")
        wstecz.setText("WSTECZ")
        wstecz.setFont(QFont('Arial', 20))
        wstecz.setGeometry(320, 583, 250, 66)
        wstecz.clicked.connect(self.podsumowanie)

        self.show()

    def rejestrowanie(self,imie1,nazwisko1,pesel1,nrtel1,adres1,data1,haslo1):
        global mydb
        self.close()

        imie = imie1.text()
        nazwisko=nazwisko1.text()
        pesel=pesel1.text()
        nrtel=nrtel1.text()
        adres=adres1.text()
        data=data1.text()
        haslo=haslo1.text()
        mycursor = mydb.cursor()
        sql = "SELECT max(ID) FROM io.customers"
        # adr = (str(imie),
        mycursor.execute(sql)
        myresult = mycursor.fetchall()
        max=int(myresult[0][0])+1

        sql = "INSERT INTO io.customers (ID, firstName, lastName, pesel, phoneNumber, adress,birthDate,password) VALUES \
              (%s, %s, %s, %s, %s, %s, %s, %s);"
        adr = (max,imie,nazwisko,pesel,nrtel,adres,data,haslo,)
        mycursor.execute(sql,adr)
        mydb.commit()

        self.zaloguj()

    def rejestracja(self):
        self.close()

        regex = QRegExp("[a-z-A-Z_]+")
        regex1 = QRegExp("[0-9.]+")
        regex2 = QRegExp("[0-9]+")
        validator = QRegExpValidator(regex)
        validator1 = QRegExpValidator(regex1)
        validator2 = QRegExpValidator(regex2)

        t = QLabel(self)
        t.setGeometry(0, 0, 900, 668)
        t.setStyleSheet("background-color: white; border : none")

        t1 = QLabel(self)
        t1.setGeometry(0, 0, 900, 668)
        t1.setStyleSheet("background-image: url(rejestracja.png); border : none")

        imie_l = QLabel(self)
        imie_l.setGeometry(150, 61, 400, 30)
        imie_l.setStyleSheet("border: none; background-color: white;")
        imie_l.setText('imię')
        imie_l.setFont(QFont('Arial', 13))

        imie = QLineEdit(self)
        imie.setMaxLength(20)
        imie.setStyleSheet("border: 2px solid line; background-color: white;")
        imie.setFont(QFont('Arial', 16))
        imie.setGeometry(300, 53, 400, 46)
        imie.setMaxLength(20)
        imie.setValidator(validator)

        nazwisko_l = QLabel(self)
        nazwisko_l.setGeometry(150, 116, 400, 30)
        nazwisko_l.setStyleSheet("border: none; background-color: white;")
        nazwisko_l.setText('nazwisko')
        nazwisko_l.setFont(QFont('Arial', 13))

        nazwisko = QLineEdit(self)
        nazwisko.setMaxLength(20)
        nazwisko.setStyleSheet("border: 2px solid line; background-color: white;")
        nazwisko.setFont(QFont('Arial', 16))
        nazwisko.setGeometry(300, 108, 400, 46)
        nazwisko.setValidator(validator)

        pesel_l = QLabel(self)
        pesel_l.setGeometry(150, 171, 400, 30)
        pesel_l.setStyleSheet("border: none; background-color: white;")
        pesel_l.setText('PESEL')
        pesel_l.setFont(QFont('Arial', 13))

        pesel = QLineEdit(self)
        pesel.setMaxLength(20)
        pesel.setStyleSheet("border: 2px solid line; background-color: white;")
        pesel.setFont(QFont('Arial', 16))
        pesel.setGeometry(300, 163, 400, 46)
        pesel.setValidator(validator2)
        pesel.setMaxLength(11)

        nrtel_l = QLabel(self)
        nrtel_l.setGeometry(150, 226, 400, 30)
        nrtel_l.setStyleSheet("border: none; background-color: white;")
        nrtel_l.setText('numer telefonu')
        nrtel_l.setFont(QFont('Arial', 13))

        nrtel = QLineEdit(self)
        nrtel.setMaxLength(20)
        nrtel.setStyleSheet("border: 2px solid line; background-color: white;")
        nrtel.setFont(QFont('Arial', 16))
        nrtel.setGeometry(300, 218, 400, 46)
        nrtel.setValidator(validator2)
        nrtel.setMaxLength(9)

        adres_l = QLabel(self)
        adres_l.setGeometry(150, 281, 400, 30)
        adres_l.setStyleSheet("border: none; background-color: white;")
        adres_l.setText('adres')
        adres_l.setFont(QFont('Arial', 13))

        adres = QLineEdit(self)
        adres.setMaxLength(20)
        adres.setStyleSheet("border: 2px solid line; background-color: white;")
        adres.setFont(QFont('Arial', 16))
        adres.setGeometry(300, 273, 400, 46)

        data_ur_l = QLabel(self)
        data_ur_l.setGeometry(150, 336, 400, 30)
        data_ur_l.setStyleSheet("border: none; background-color: white;")
        data_ur_l.setText('data urodzenia')
        data_ur_l.setFont(QFont('Arial', 13))

        data_ur = QLineEdit(self)
        data_ur.setMaxLength(20)
        data_ur.setStyleSheet("border: 2px solid line; background-color: white;")
        data_ur.setFont(QFont('Arial', 16))
        data_ur.setGeometry(300, 328, 400, 46)
        data_ur.setValidator(validator1)
        data_ur.setMaxLength(10)

        password_l = QLabel(self)
        password_l.setGeometry(150, 391, 400, 30)
        password_l.setStyleSheet("border: none; background-color: white;")
        password_l.setText('hasło')
        password_l.setFont(QFont('Arial', 13))

        password = QLineEdit(self)
        password.setMaxLength(20)
        password.setStyleSheet("border: 2px solid line; background-color: white;")
        password.setFont(QFont('Arial', 16))
        password.setGeometry(300, 383, 400, 46)


        anuluj = QPushButton(self)
        anuluj.setStyleSheet("border-radius:25; background-color: gray;")
        anuluj.setGeometry(295, 488, 190, 61)
        anuluj.setText("ANULUJ")
        anuluj.setFont(QFont('Arial', 16))
        anuluj.clicked.connect(self.zaloguj)

        potwierdz = QPushButton(self)
        potwierdz.setStyleSheet("border-radius:25; background-color: gray;")
        potwierdz.setGeometry(520, 488, 190, 61)
        potwierdz.setText("ZATWIERDŹ")
        potwierdz.setFont(QFont('Arial', 16))
        potwierdz_p=partial(self.rejestrowanie,imie,nazwisko,pesel,nrtel,adres,data_ur,password)
        potwierdz.clicked.connect(potwierdz_p)


        self.show()

    def check(self,kod,x):
        global kwota,mydb,zalogowany,klientID
        value = kod.text()
        if len(str(value)) < 6:
            kod.setText("")
            x.setStyleSheet("border: none; background-color: white; color: red")
        else:
            sql = "SELECT max(ID) FROM io.transactions"
            mycursor = mydb.cursor()
            mycursor.execute(sql)
            myresult = mycursor.fetchall()
            max = int(myresult[0][0]) + 1

            if klientID==0:
                sql = "INSERT INTO io.transactions(ID,customerID,price,date) VALUES \
                              (%s, null, %s, current_date());"
                adr = (max, float(kwota),)
                mycursor.execute(sql, adr)
                mydb.commit()
            else:
                sql = "INSERT INTO io.transactions(ID,customerID,price,date) VALUES \
                                              (%s, %s, %s, current_date());"
                adr = (max,str(klientID),float(kwota),)
                mycursor.execute(sql, adr)
                mydb.commit()
            self.koniec()

    def Blik(self):
        self.close()
        global kwota,zalogowany

        tlo = QLabel(self)
        tlo.setGeometry(0, 0, 900, 668)
        tlo.setStyleSheet("background-color: white; border: none")

        t = QLabel(self)
        t.setGeometry(0, 0, 900, 668)
        t.setStyleSheet("background-image: url(blik.png); border : none")

        anuluj = QPushButton(self)
        anuluj.setStyleSheet("border-radius:40; background-color: gray;")
        anuluj.setGeometry(210, 493, 270, 91)
        anuluj.setText("ANULUJ")
        anuluj.setFont(QFont('Arial', 20))
        if zalogowany==0:
            anuluj.clicked.connect(self.podsumowanie)
        else:
            anuluj.clicked.connect(self.zalogowany)

        Kwota = QLabel(self)
        Kwota.setStyleSheet("border: none background-color: white;")
        Kwota.setGeometry(621, 220, 270, 91)
        Kwota.setText(kwota + "zł")
        Kwota.setFont(QFont('Arial', 20))

        kod = QLineEdit(self)
        kod.setValidator(QIntValidator())
        kod.setMaxLength(6)
        kod.setStyleSheet("border: none; background-color: white;")
        kod.setFont(QFont('Arial', 20))
        kod.setGeometry(510, 373, 250, 96)


        x = QLabel(self)
        x.setStyleSheet("border: none; background-color: white; color: white")
        x.setText("BŁĘDNY KOD!")
        x.setFont(QFont('Arial', 12))
        x.setGeometry(570, 330, 135, 30)

        tmp = partial(self.check, kod,x)

        zatw = QPushButton(self)
        zatw.setStyleSheet("border-radius:40; background-color: gray;")
        zatw.setGeometry(501, 493, 270, 91)
        zatw.setText("ZATWIERDŹ")
        zatw.setFont(QFont('Arial', 20))
        zatw.clicked.connect(tmp)
        self.show()

    def Karta(self):
        global zalogowany
        self.close()

        t1 = QLabel(self)
        t1.setGeometry(0, 0, 900, 668)
        t1.setStyleSheet("background-image: url(karta.png); border : none")

        Kwota = QLabel(self)
        Kwota.setStyleSheet("border: none background-color: white;")
        Kwota.setGeometry(421, 180, 270, 91)
        Kwota.setText(kwota + "zł")
        Kwota.setFont(QFont('Arial', 20))

        anuluj = QPushButton(self)
        anuluj.setStyleSheet("border-radius:40; background-color: gray;")
        anuluj.setGeometry(341, 500, 270, 91)
        anuluj.setText("ANULUJ")
        anuluj.setFont(QFont('Arial', 20))
        if zalogowany==0:
            anuluj.clicked.connect(self.podsumowanie)
        else:
            anuluj.clicked.connect(self.zalogowany)



        self.show()

    def koniec(self):
        global products,kwota,zalogowany,klientID,obecny_produkt
        products = []
        kwota = '0.00'
        obecny_produkt = ''
        zalogowany = 0
        klientID = 0

        self.close()
        t=QLabel(self)
        t.setGeometry(0, 0, 900, 688)
        t.setStyleSheet("background-color:white; border: none")

        t1 = QPushButton(self)
        t1.setGeometry(0, 0, 900, 673)
        t1.setStyleSheet("background-image: url(koniec.png); border : none")
        t1.clicked.connect(self.restart)

        self.show()


class ScrollLabel(QScrollArea):

    def __init__(self, *args, **kwargs):
        QScrollArea.__init__(self, *args, **kwargs)

        self.setWidgetResizable(True)

        content = QWidget(self)
        self.setWidget(content)

        lay = QVBoxLayout(content)

        self.label = QLabel(content)

        self.label.setAlignment(Qt.AlignLeft | Qt.AlignTop)

        self.label.setWordWrap(True)

        lay.addWidget(self.label)

    def setText(self, text):
        self.label.setText(text)

App = QApplication([])
window = Window()
App.exec_()